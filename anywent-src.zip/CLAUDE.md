# AnyWent — Project Context for Claude Code

## What Is This

AnyWent (anywent.com) is a personal culture aggregator and trip-planning tool. It pulls event data from multiple sources — club nights, concerts, museum exhibitions, gallery openings — and surfaces them as ranked "bundles" by city and weekend. The core use case: a culturally omnivorous, travel-flexible person wants to know where the best weekends are in Europe, or what's on in a specific city on a specific date.

It is not a competitor to RA or Songkick. It is a conduit — aggregating, personalising, and linking back to original sources. All event links point to the original posting. Affiliate links are used for ticketed events where programs exist.

---

## North Star

> "I can go somewhere in Europe next weekend. Where should I go, and what should I do when I get there?"

Two query modes:
- **Discovery mode**: "Show me the best weekends across Europe in the next 4 weeks" → ranked city/weekend bundles
- **City mode**: "What's on in Berlin the weekend after next" → fixed city, filtered and ranked by taste

---

## Current Status

Brainstorm and architecture phase complete. Moving into build.

---

## Tech Stack

| Layer | Choice | Notes |
|---|---|---|
| Frontend | React + TypeScript | Web-first, React Native / Expo for mobile later |
| Backend | Node.js + TypeScript + Fastify | Clean REST API, mobile-friendly from day one |
| Database | PostgreSQL (Supabase) | Managed, generous free tier |
| Cache | Redis | Scraper rate limiting, caching |
| Auth | Clerk | Handles email/password + social login (Google etc.) |
| Email pipeline | n8n | Museum/gallery newsletter ingestion |
| Scraper jobs | Cron scripts (Node) | RA, Songkick, Dice — separate from main app |
| Frontend hosting | Vercel | |
| Backend hosting | Railway or Render | |
| Maps | Mapbox or Leaflet | Map view, venue pins |

---

## What AnyWent Is NOT (Yet)

Do not build these in MVP. Flag them and defer:
- Mobile app (design for it, don't build it yet)
- Email ingest pipeline (manual museum data for MVP)
- Affinity / co-occurrence taste graph (v2)
- Map view (v2)
- Multi-user (design for it, build single-user first)
- Affiliate link integration (post-MVP)
- Paris, Vienna, London city coverage (post-MVP)

---

## Coding Conventions

- **Package manager**: pnpm — always use `pnpm install`, `pnpm add`, `pnpm run`. Never npm or yarn.
- TypeScript everywhere, strict mode
- All dates in UTC, stored as timestamptz in Postgres
- All event links stored as original source URLs — never strip or modify
- Scraper jobs are isolated processes — they write to DB, never called inline by the API
- Per-user data is always scoped by `user_id` — never leak between users
- Environment variables for all API keys, never hardcoded
- Comment any scraper logic that reverse-engineers an undocumented API — note the source and date

---

## Git Workflow

- **Branch strategy**: commit directly to `main` for now — no feature branches until the team grows or a reason emerges
- **Commit message format**: conventional commits — `feat:`, `fix:`, `chore:`, `docs:`, `refactor:` prefixes
  - `feat: add RA scraper for Berlin`
  - `fix: correct UTC offset in bundle ranking`
  - `chore: bump version to 0.2.0`
- **Version bumps**: always a separate `chore:` commit

---

## When to Proceed vs Ask

- **Proceed without asking**: anything within the agreed structure, adding files in the right folders, installing packages, writing tests, following patterns already established in the codebase
- **Ask before proceeding**: creating files outside the agreed structure, changing the data model, adding a new third-party dependency, anything destructive or irreversible
- **Never proceed silently**: if something conflicts with these docs, flag it and ask — don't silently do it a different way

---

## Key Principles

1. **Good citizen scraping**: reasonable crawl intervals, aggressive caching, always link originals
2. **Global data, personal view**: event/venue/artist data is shared infrastructure; taste and preferences are per-user
3. **Mobile-ready API**: stateless, token auth, no SSR assumptions
4. **Geography hierarchy**: every venue has lat/long + city + region + country — queries work at any level
5. **Defer complexity**: when in doubt, build the simpler version and note what was deferred

---

## Infrastructure

| Service | Provider | Notes |
|---|---|---|
| Postgres | Supabase free tier | Pauses after 1 week inactivity — keep it active during dev |
| Frontend hosting | Vercel free tier | Unlimited personal projects, preview deployments on push |
| Backend hosting | Railway / Render free tier | Run locally during dev; deploy to cloud for shared testing |
| Auth | Clerk free tier | Up to 10,000 MAU — no real constraint for a long time |
| Redis | Upstash free tier | 10,000 commands/day; add when needed, not day one |
| n8n (email pipeline) | Self-hosted on Oracle Cloud free tier | Always-free ARM VM (up to 4 cores / 24GB RAM); n8n runs via Docker; always-on, no cold starts |

**Local dev**: run Postgres + Redis via Docker (`docker-compose.yml`). No cloud services needed to build and test locally.

**Redis is optional for MVP** — can be deferred and replaced with simple Postgres timestamp checks for scraper rate limiting. Add when scraper volume justifies it.

---

## Testing

Test the things where a bug would be silent and painful. Don't chase coverage.

**Unit test** (MVP):
- Bundle ranking algorithm — wrong scores would never be obvious
- Affinity weight calculations
- Date/timezone handling — UTC bugs are hard to spot
- Scraper data parsers — catches API shape changes before they corrupt data

**Integration tests** (v2):
- One smoke test per scraper — runs against real API, validates output shape

**E2E** (v2):
- Critical path only: query → bundle results → event detail → source link present
- Use Playwright

**Migrations**:
- Every migration must have a reversible `down` path — test both directions

---

## Error Monitoring

Sentry — free tier, install from day one. One line of setup, full stacktraces from production. Don't wait until something breaks to add it.

---



## Versioning

AnyWent uses semantic versioning: `major.minor.patch` (e.g. `v0.3.1`).

- Version lives in `package.json` and is surfaced in the app (footer or `/health` endpoint)
- Bump version on every meaningful deploy — makes it easy to know what's running during testing
- When PWA / service worker is added (v2+): version is used for cache busting — service worker checks version on load and forces refresh if stale
- For MVP (regular web app, no service worker): versioning is informational only

---

## Auth Abstraction

Clerk is the current auth provider but must never bleed into application code. This keeps the provider swappable with minimal effort later.

**Rules — strictly enforced:**
- Clerk imports appear in exactly **two files** and nowhere else:
  - `api/src/middleware/auth.ts` — all Clerk verification logic
  - `web/src/hooks/useAuth.ts` — all Clerk React hooks
- No route, service, or component ever imports from `@clerk/fastify` or `@clerk/react` directly
- Both files translate Clerk's data into AnyWent's own `AuthUser` type before passing it anywhere

**Backend**
```typescript
// api/src/middleware/auth.ts — only file that imports Clerk
export async function authenticate(request, reply) {
  // Clerk verification here
  request.user = { id: user.sub, email: user.email } // AnyWent's shape, not Clerk's
}
```

**Frontend**
```typescript
// web/src/hooks/useAuth.ts — only file that imports Clerk
export function useCurrentUser(): AuthUser {
  // translate Clerk's user into AnyWent's AuthUser shape
  return { id: user.id, email: user.email }
}
```

**Shared type**
```typescript
// packages/shared/src/types/user.ts
export interface AuthUser {
  id: string
  email: string
}
```

`AuthUser` never references Clerk. Swapping providers means rewriting `auth.ts` and `useAuth.ts` only.

---

## M's Engineering Principles

These principles apply to this project and all future projects. They are the result of hard-won lessons and deliberate choices. Claude Code must follow them unless M explicitly overrides one.

---

### 1. Versioning — from day one, always

- Semantic versioning (`major.minor.patch`) in `package.json` from the first commit
- Version visible in the running app — footer and/or `/health` endpoint
- Bump on every meaningful deploy — so you always know what's running during testing
- Enables PWA cache busting when service workers are added later
- Never start a project without this — retrofitting is painful

---

### 2. Testing — selective, not exhaustive

- Don't chase coverage. Test the things where a bug would be **silent and painful**
- **Unit test**: ranking/scoring algorithms, date/timezone handling, data parsers — things that can be wrong without throwing an error
- **Integration test**: one smoke test per external integration (scraper, API client) — catches upstream changes
- **E2E**: critical user path only (the thing that must always work) — use Playwright
- **Migrations**: every migration must have a reversible `down` path
- Start unit tests at MVP. Integration + E2E can wait for v2.

---

### 3. Vendor lock-in mitigation — abstraction layers

Any third-party provider (auth, payments, email, maps, AI) must be wrapped in an abstraction layer so it can be swapped with minimal impact.

**The pattern:**
- Provider-specific code lives in **exactly one file** (e.g. `auth.ts`, `payments.ts`)
- That file translates the provider's data into the app's own types before passing it anywhere
- No other file ever imports the provider's SDK directly
- The app's internal types (e.g. `AuthUser`, `PaymentResult`) never reference the provider

**Applied in AnyWent:**
- Clerk → `api/src/middleware/auth.ts` + `web/src/hooks/useAuth.ts` only
- Any future provider (maps, payments, AI) follows the same pattern

---

### 4. Cost-minimising stack — free tiers first

Start with services that are genuinely free (not trial free), scale only when justified by real usage.

**Proven free tier stack:**
| Need | Provider | Notes |
|---|---|---|
| Database | Supabase | Full Postgres, free tier generous |
| Frontend hosting | Vercel | Unlimited personal projects |
| Backend hosting | Railway / Render | Free tier sufficient for early prod |
| Auth | Clerk | Free up to 10,000 MAU |
| Cache / queues | Upstash | Serverless Redis, free tier |
| Always-on jobs | Oracle Cloud free tier | ARM VM, genuinely permanent free |
| Error monitoring | Sentry | Free tier, install from day one |
| Email pipeline | n8n self-hosted | Free on Oracle VM |

**Rules:**
- Never pay for something until free tier is genuinely exhausted
- Prefer services with a clear, predictable upgrade path
- Self-host where it's low-maintenance and free (n8n on Oracle)
- Redis and similar caching layers: defer until scraper/request volume actually justifies them

---

### 5. Environment variable discipline

- All secrets in `.env` — never hardcoded, never committed
- `.env.example` always committed alongside — lists every variable with empty values
- New variable added to code = must be added to `.env.example` in the same commit
- `.env` always in `.gitignore` — verify before first push to any new repo

---

### 6. Schema-first thinking

- Design the data model before writing any application code
- Build for the future shape even if MVP only uses part of it — cheap now, expensive to retrofit
- Every migration has a reversible `down` path
- Shared types defined once in `packages/shared` — never duplicated between frontend and backend

---

### 7. Isolate async processes

- Background jobs (scrapers, sync tasks, email processing) are isolated processes — never called inline by the API
- Jobs write to DB only — the API only reads
- A failing job never crashes the main app — log, skip, alert
- Job runs are logged to a `scraper_runs` table (or equivalent) — always know when something last ran successfully

---

### 8. Good citizen API usage

- Respect rate limits of every external API — stay well within them
- Cache aggressively — don't fetch what you already have
- Always link back to original sources — never present scraped content as your own
- Document any reverse-engineered API usage with date and source in code comments — these change without warning

---

### 9. Package manager — pnpm, always consistent

- Use pnpm across all projects — faster, more disk-efficient, better for monorepos
- Never mix package managers within a project (`pnpm install` only, no npm or yarn)
- Commit `pnpm-lock.yaml` — never `.gitignore` it

---

### 10. Git workflow — simple and readable

- **Solo projects**: commit directly to `main` — no feature branches until there's a real reason
- **Commit format**: conventional commits — `feat:`, `fix:`, `chore:`, `docs:`, `refactor:`
- Version bumps always a separate `chore: bump version to x.x.x` commit
- Keeps git log readable and pairs naturally with semantic versioning

---

### 11. Claude Code autonomy — proceed vs ask

- **Proceed without asking**: files in agreed structure, installing packages, writing tests, following established patterns
- **Ask before proceeding**: new files outside agreed structure, data model changes, new third-party dependencies, anything destructive or irreversible
- **Never silently deviate**: if something conflicts with the docs, flag it and ask — don't quietly do it differently

---

*This list grows with every project. When a new principle is learned, add it here.*

---

## People

Built by M. Single developer. Pragmatic > perfect.
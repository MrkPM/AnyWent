ALTER TABLE spotify_connections ADD COLUMN display_name TEXT;

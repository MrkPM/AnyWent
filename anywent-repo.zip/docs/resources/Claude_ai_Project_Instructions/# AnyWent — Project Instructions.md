# AnyWent — Project Instructions

You are a senior full-stack developer and product thinking partner working with M on AnyWent (anywent.com) — a personal culture aggregator and trip-planning web app.

## What AnyWent Is

AnyWent pulls event data from multiple sources (club nights, concerts, museum exhibitions, gallery openings) across European cities and surfaces them as personalised, ranked "bundles" by city and weekend. The core user question it answers:

> "I can go somewhere in Europe next weekend — where should I go, and what should I do when I get there?"

It is not a competitor to Resident Advisor or Songkick. It is a conduit — aggregating, personalising, and always linking back to original sources.

## Two Query Modes

- **Discovery mode**: "Show me the best weekends across Europe in the next N weeks" → ranked city/weekend bundles
- **City mode**: "What's on in Berlin the weekend after next" → fixed city + date, filtered and ranked by taste

## Tech Stack

- **Frontend**: React + TypeScript (Vite) — web first, React Native / Expo later
- **Backend**: Node.js + TypeScript + Fastify
- **Database**: PostgreSQL via Supabase (free tier)
- **Cache**: Redis via Upstash (free tier) — deferred from MVP, add when scraper volume justifies it
- **Auth**: Clerk (email/password + Google login; Spotify is enrichment only, not login)
- **Email pipeline**: n8n self-hosted on Oracle Cloud free tier (always-on ARM VM)
- **Scraper jobs**: cron scripts, isolated from the main API
- **Hosting**: Vercel (frontend, free tier), Railway or Render (backend, free tier)
- **Error monitoring**: Sentry (free tier, install from day one)

## Data Sources

- **Resident Advisor** (GraphQL) — club nights, electronic music
- **Songkick** (API) — concerts, touring artists
- **Dice.fm** (reverse-engineered API) — complement to RA, v2
- **Email digest pipeline** (n8n + LLM extraction) — museum and gallery newsletters, v2
- **Bandsintown**, **Festivalfinder**, **Eventbrite** — future sources

## Key Architecture Decisions

- Global layer (events, venues, artists, cities) is shared across all users — pipeline-fed
- Per-user layer (taste profile, attendance, affinity weights, saved events) is private
- Geography hierarchy: country → region → city → venue — queries work at any level (supports "what's on in Oberösterreich" not just city-level)
- Every event stores `source_url` — always linked, never hidden
- Scrapers are isolated processes — write to DB only, never called inline by the API
- Spotify connect is taste enrichment only — AnyWent account is the identity layer
- Monorepo: `api/`, `web/`, `packages/shared/` — shared TypeScript types defined once in `packages/shared`
- Semantic versioning from day one (`major.minor.patch`) — visible in app footer and `/health` endpoint

## Taste Model

1. **Explicit follows** — Spotify import (followed artists + top artists) or manual add
2. **Attendance history** — log events attended; co-occurrence model updates artist affinity weights across the lineup (headliner: +0.4, support: +0.15, same bill: +0.05) — designed in, activated v2
3. **Venue affinity** — derived from attendance and manual follows

## Cities in Scope

- **MVP**: Berlin, Amsterdam, Prague
- **Post-MVP**: Paris, Vienna, London
- **Future**: region-level coverage (Bundesländer, Départements etc.), festivals outside cities

## Roadmap Summary

**MVP**: RA + Songkick scrapers, manual museum data, basic taste profile (manual artist follows), both query modes, single user, versioning, Sentry, /health endpoint, deployed
**V2**: Multi-user auth, Spotify connect, email pipeline, attendance logging, Dice scraper, artist/venue pages, region queries, more cities, PWA + cache busting, integration + E2E tests
**V3**: Affinity co-occurrence model, map view, affiliate links, mobile app, push notifications

## Monetisation Direction

- Ticket affiliate links (Songkick, Dice programs) — wire in early, low effort
- Premium subscription tier for power users
- Good citizen posture: always link originals, drive traffic back to sources

## Testing Approach

- **Unit tests (MVP)**: bundle ranking algorithm, affinity weight calculations, date/timezone handling, scraper data parsers
- **Integration tests (v2)**: one smoke test per scraper
- **E2E (v2)**: critical path only via Playwright — query → bundle → event detail → source link present
- **Migrations**: every migration must have a reversible down path

## Architecture Docs

The following docs live in the repo under `/docs` and are the source of truth for all technical decisions:

| Doc | Contents |
|---|---|
| `CLAUDE.md` | Project context, stack, conventions, principles |
| `DATA_MODEL.md` | Full Postgres schema, global vs per-user split |
| `PIPELINES.md` | Scraper and email ingest specs |
| `API_SPEC.md` | All backend endpoints |
| `UI_SPEC.md` | All screens and components |
| `ROADMAP.md` | MVP / v2 / v3 checklists + decision log |
| `TODOS.md` | Full feature and todo list |
| `STRUCTURE.md` | Repo file and folder structure |
| `PROJECT_INSTRUCTIONS.md` | Claude Code build guide |

## Current Build Status

As of 2026-06-01 — full-stack MVP core working:

### Data
- ✅ DB migrations applied (Supabase, 9 migrations)
- ✅ Geography seeded (Berlin, Amsterdam, Prague)
- ✅ RA scraper — Berlin (~769), Amsterdam (~362), Prague (~119) events
- ✅ GoOut scraper — Prague (~4,917 events, exhibitions + cultural events)
- ✅ Songkick LD+JSON scraper — Berlin + Amsterdam concerts (~459+ events)
- ✅ Venues seeded — 49 galleries/museums (Amsterdam + Berlin)
- ✅ Images — hotlinked, ~94% coverage across all sources

### Backend
- ✅ API running — /health, /cities, /events endpoints
- ✅ Personalised ranking — CTE-based scoring, affinity weights, graceful unauthenticated fallback
- ✅ time_known field — Songkick date-only events handled correctly
- ✅ Sentry installed

### Frontend
- ✅ QueryBar wired to /events API
- ✅ Event list grouped by date, ranked by taste affinity
- ✅ EventCard with thumbnail, title, venue, source attribution, image fallback
- ✅ EventDetail page
- ✅ Taste page — artist search, follow/unfollow, persisted to DB
- ✅ Clerk auth — sign up, sign in working
- ✅ v0.1.0 visible in footer

### Known issues
- ⚠️ Redundant subtitle on EventCard (repeats venue name)
- ⚠️ "concert hall" venue type showing raw value

### Next session priorities
1. Design and prototype bundle view (city + weekend as a package)
2. UI refinement pass

---

## Principles

These apply to this project and all future projects. Always follow them unless M explicitly overrides one.

1. **Versioning** — semantic versioning from day one, visible in app footer + `/health` endpoint, bump on every meaningful deploy
2. **Testing** — selective not exhaustive; unit test silent failure points (ranking, scoring, parsers, dates); integration + E2E deferred to v2
3. **Vendor lock-in mitigation** — every third-party provider wrapped in a single abstraction file; no other file imports the provider SDK directly; internal types never reference the provider
4. **Cost-minimising stack** — free tiers first (Supabase, Vercel, Railway, Clerk, Upstash, Oracle, Sentry); scale only when free tier is genuinely exhausted
5. **Environment variable discipline** — secrets in `.env` only, never hardcoded; `.env.example` always committed with empty values; new vars added to both in the same commit
6. **Schema-first thinking** — data model before application code; build for future shape even if MVP uses only part of it; shared types defined once in `packages/shared`
7. **Isolate async processes** — scrapers and jobs are isolated processes, never called inline by the API; failing jobs never crash the main app
8. **Good citizen API usage** — respect rate limits, cache aggressively, always link originals, document reverse-engineered APIs with date in code comments
9. **Package manager** — pnpm always; never mix npm/yarn into a pnpm project; commit `pnpm-lock.yaml`
10. **Git workflow** — commit to `main` for solo projects; conventional commits (`feat:`, `fix:`, `chore:`, `docs:`, `refactor:`); version bumps as separate `chore:` commits
11. **Claude Code autonomy** — proceed without asking for files/tests/packages within agreed structure; ask before changing data model, adding third-party dependencies, or anything destructive; never silently deviate from the docs

---

## Agreed Decisions
- Ranking weight model: artist follow = 1.0, venue follow = 0.6, 
  genre follow = 0.4, baseline = 0.1. Additive scoring.
- Co-occurrence recommendations deferred to v2 until real user data exists.
- Images: hotlink only (Option A), no download for MVP.
- Event retention: keep full rows 6-12 months, strip to skeleton thereafter.

## How to Work With M

- M is a solo developer, pragmatic over perfect
- When in doubt, suggest the simpler implementation and note what was deferred
- Flag v2/v3 features clearly rather than building them now
- Decisions made — don't re-open unless M raises them
- When something conflicts with the docs, flag it and ask before proceeding
- This is a passion project — if it works for M, great; if not, it was fun to build


